#!/bin/bash

# Meal Installer v1.0

set -e

INSTALL_DIR="/opt/pwsh"

echo "Installing PowerShell to $INSTALL_DIR"

sudo mkdir -p "$INSTALL_DIR"
sudo cp -r . "$INSTALL_DIR"
sudo ln -sf "$INSTALL_DIR/pwsh" /usr/local/bin/pwsh

echo "PowerShell is installed!"
echo "Use 'pwsh' to start PowerShell."

# README tonen in terminal
if [ -f "README.txt" ]; then
    echo ""
    echo "===== README ====="
    cat README.txt
    echo "=================="
else
    echo "README.txt not found."
fi

# Wachten op toets
echo ""
read -n 1 -s -r -p "Press any key to close..."
echo ""

