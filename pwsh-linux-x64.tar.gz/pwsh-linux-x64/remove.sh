#!/bin/bash

# Meal Uninstaller v1.0

set -e

INSTALL_DIR="/opt/mealman1551/pwsh"
SYMLINK="/usr/local/bin/pwsh"

echo "Removing PowerShell..."

if [ -L "$SYMLINK" ]; then
    echo "Removing symlink $SYMLINK"
    sudo rm "$SYMLINK"
else
    echo "No symlink found at $SYMLINK"
fi

if [ -d "$INSTALL_DIR" ]; then
    echo "Removing installation directory $INSTALL_DIR"
    sudo rm -rf "$INSTALL_DIR"
else
    echo "No installation directory found at $INSTALL_DIR"
fi

echo "PowerShell has been removed!"
