This package contains PowerShell for Debian Trixie as of currently (6.10.2025) PowerShell isn't available for Debian 13 (Trixie) yet.

The PowerShell version is: 7.3.4

I, Mealman1551, have compiled PowerShell to work on Debian Trixie.

When PowerShell is fully supported by Microsoft i will archive the repository of this port.

Install instructions:

Run `install.sh`, the script will make a symlink so PowerShell works properly.

To remove run: `remove.sh`

Thats all!

~Mealman1551

ps,

PowerShell is made by Microsoft, this port is builded by Mealman1551 to support Debian 13 and its not modified in any way.


